/**
 * 
 */
package java8features;

import java.util.Arrays;
import java.util.List;

/**
 * @author Bhavana Malli
 *
 */
public class LambdaExpression {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<String> names = Arrays.asList("John", "Mary", "Bob");
	        
	        names.forEach(name -> System.out.println(name));

	}

}
