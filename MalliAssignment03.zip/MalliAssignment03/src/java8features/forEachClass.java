/**
 * 
 */
package java8features;

/**
 * @author Bhavana Malli
 *
 */
public class forEachClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers = {1, 2, 3, 4, 5};

		for (int number : numbers) {
		    System.out.println(number);
		}

	}

}
