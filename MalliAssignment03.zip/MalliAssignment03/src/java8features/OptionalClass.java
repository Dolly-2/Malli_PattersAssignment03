/**
 * 
 */
package java8features;

import java.util.Optional;

/**
 * @author Bhavana Malli
 *
 */
public class OptionalClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        String name = null;
        
        Optional<String> optionalName = Optional.ofNullable(name);
        
        if (optionalName.isPresent()) {
            System.out.println("Name: " + optionalName.get());
        } else {
            System.out.println("Name not found.");
        }
    }

}
