/**
 * 
 */
package java8features;

import java.util.function.Function;
import java.util.function.Predicate;

/**
 * @author Bhavana Malli
 *
 */
public class JavaFunctionalInterfaces {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        Predicate<Integer> isEven = n -> n % 2 == 0;
        System.out.println(isEven.test(4)); // true
        System.out.println(isEven.test(5)); // false
        
        Function<Integer, String> intToString = n -> String.valueOf(n);
        String str = intToString.apply(42);
        System.out.println(str); // "42"
    }

}
