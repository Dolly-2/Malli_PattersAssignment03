/**
 * 
 */
package generic;

/**
 * @author Bhavana Malli
 *
 */
public class GenClass<T> {
	 private T obj = null;
     
	    //constructor to accept type parameter T
	    public GenClass(T param){
	        this.obj = param;
	    }
	     
	    public T getObj(){
	        return this.obj;
	    }
	     
	    //this method prints the holding parameter type
	    public void printType(){
	        System.out.println("Type: "+obj.getClass().getName());
	    }
	

}
