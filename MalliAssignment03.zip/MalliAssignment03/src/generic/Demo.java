/**
 * 
 */
package generic;

/**
 * @author Bhavana Malli
 *
 */
public class Demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 //we are going to create genericsClass object with String as type parameter
		GenClass<String> gcd = new GenClass<String>("JAVA2NOVICE");
		gcd.printType();
        //we are going to create genericsClass object with Boolean as type parameter
        GenClass<Boolean> gfd = new GenClass<Boolean>(Boolean.TRUE);
        gcd.printType();
		

	}

}
