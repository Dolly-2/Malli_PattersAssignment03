/**
 * 
 */
package covariantdemo;

/**
 * @author Bhavana Malli
 *
 */
public class Car extends Vehicle {
	
		public Car getInstance() {
		return this;
		}
		public void move() {
		System.out.println("Car is a Luxury ...");
		}

}
