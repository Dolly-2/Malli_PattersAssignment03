/**
 * 
 */
package covariantdemo;

/**
 * @author Bhavana Malli
 *
 */
public class Vehicle {
	public Vehicle getInstance() {
		return this;
		}

}
