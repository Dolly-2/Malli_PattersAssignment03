/**
 * 
 */
package covariantdemo;

/**
 * @author Bhavana Malli
 *
 */
public class CovarientTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Car().getInstance().move();
	}

}
