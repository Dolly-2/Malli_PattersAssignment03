/**
 * 
 */
package Final;

/**
 * @author Bhavana Malli
 *
 */
public class finalKeyword {
	  final int age = 18;  
	    void display() {  
	      
	    // reassigning value to age variable   
	    // gives compile time error  
	  //  age = 55;  
	    }  

}
