/**
 * 
 */
package Final;

/**
 * @author Bhavana Malli
 *
 */
public class finalTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		finalKeyword obj = new finalKeyword();
		
		
	    //gives compile time error  
	    obj.display();  
	    }  
	}


