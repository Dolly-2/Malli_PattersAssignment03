/**
 * 
 */
package HashMapHashTable;

/**
 * @author Bhavana Malli
 *
 */
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
public class HashMapTableDemo {

	/**
	 * @param args
	 */
	

	public static void main(String[] args) {
	    
		      // Example of using Hashtable
		      Map<String, Integer> hashtable = new Hashtable<String, Integer>();
		      hashtable.put("John", 30);
		      hashtable.put("Mary", 25);
		      hashtable.put("Bob", 40);
		      // hashtable.put(null, 50);  // throws a NullPointerException
		      System.out.println("Hashtable: " + hashtable);
		      
		      // Example of using HashMap
		      Map<String, Integer> hashmap = new HashMap<String, Integer>();
		      hashmap.put("John", 30);
		      hashmap.put("Mary", 25);
		      hashmap.put("Bob", 40);
		      hashmap.put(null, 50);
		      System.out.println("HashMap: " + hashmap);
		   }
		

	}


