/**
 * 
 */
/**
 * @author S555841
 *
 */
module MalliAssignment03 {
}