/**
 * 
 */
package StringBuilderAndBufferClass;

/**
 * @author Bhavana Malli
 *
 */
public class BufferExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 StringBuffer buffer = new StringBuffer(" Welcome ");
	      buffer.append("To Northwest Missouri State Universty");
	      System.out.println("StringBufferExample" +buffer);
	}

}
