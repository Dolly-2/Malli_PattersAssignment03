/**
 * 
 */
package StringBuilderAndBufferClass;

/**
 * @author Bhavana Malli
 *
 */
public class BuilderExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 StringBuilder build =new StringBuilder("Hello");
	      build.append(" Maryville!!!");
	      System.out.println("StringBuilderExample " +build);

	}

}
