/**
 * 
 */
package StringBuilderAndBufferClass;

/**
 * @author Bhavana Malli
 *
 */
public class StringClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String string=new String ("Cognizant");
		string.concat("Solution");
		System.out.println(string);

	}

}
