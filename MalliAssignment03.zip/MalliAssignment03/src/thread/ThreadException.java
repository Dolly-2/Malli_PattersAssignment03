/**
 * 
 */
package thread;

/**
 * @author Bhavana Malli
 *
 */
public class ThreadException {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Thread myThread = new Thread(() -> {
		    System.out.println("Thread started");
		});

		myThread.start(); // start the thread

		try {
		    Thread.sleep(1000);
		} catch (InterruptedException e) {
		    e.printStackTrace();
		}

		myThread.start(); // start the same thread again

		// The above statement will throw an IllegalThreadStateException


	}

}
