/**
 * 
 */
package overrideDemo;

/**
 * @author Bhavana Malli
 *
 */
public class Planet {
	public static void printName() {
        System.out.println("Planet");
    }

    void rotate() {
        System.out.println("The planet is rotating.");
    }

}
