/**
 * 
 */
package overrideDemo;

/**
 * @author Bhavana Malli
 *
 */
public class Earth extends Planet {
	public void rotate() {  // override
	     System.out.println("Earth is rotating ...!");  

}
}
