/**
 * 
 */
package SynchronizedSingleton;

/**
 * @author Bhavana Malli
 *
 */
public class Singleton {
    private static Singleton instance;
    
    private Singleton() {
        // Private constructor to prevent outside instantiation
    }
    
    public static synchronized Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }
    
    public void sayHello() {
        System.out.println("Hello from Singleton instance");
    }
}


