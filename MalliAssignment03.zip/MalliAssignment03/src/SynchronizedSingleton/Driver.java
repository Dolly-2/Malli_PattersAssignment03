/**
 * 
 */
package SynchronizedSingleton;

/**
 * @author Bhavana Malli
 *
 */
public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Singleton singleton1 = Singleton.getInstance();
        Singleton singleton2 = Singleton.getInstance();
        
        System.out.println(singleton1 == singleton2); // true
        
        singleton1.sayHello(); // "Hello from Singleton instance"
        singleton2.sayHello(); // "Hello from Singleton instance"

	}

}
