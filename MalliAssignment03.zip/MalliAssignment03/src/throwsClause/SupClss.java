/**
 * 
 */
package throwsClause;

import java.io.IOException;

/**
 * @author Bhavana Malli
 *
 */
public class SupClss {
	public static void main(String[] args) {
		SupClss x = new SupClss();
		}
}
