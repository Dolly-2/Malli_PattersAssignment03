/**
 * 
 */
package throwsClause;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author Bhavana Malli
 *
 */
public class Subclss extends SupClss{
    void msg() throws ArithmeticException {
        System.out.println("Hello");
  }
}
