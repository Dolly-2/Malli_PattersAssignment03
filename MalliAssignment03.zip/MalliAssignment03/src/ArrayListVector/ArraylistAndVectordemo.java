/**
 * 
 */
package ArrayListVector;

/**
 * @author Bhavana Malli
 *
 */
import java.util.ArrayList;
import java.util.Vector;
public class ArraylistAndVectordemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
 
		      ArrayList<String> list1 = new ArrayList<String>();
		      list1.add("Apple");
		      list1.add("Banana");
		      list1.add("Cherry");
		      System.out.println("ArrayList: " + list1);
		      
		      // Example of using Vector
		      Vector<String> list2 = new Vector<String>();
		      list2.add("Dog");
		      list2.add("Cat");
		      list2.add("Fish");
		      System.out.println("Vector: " + list2);
		   }
}


