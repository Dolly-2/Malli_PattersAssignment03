/**
 * 
 */
package differentwaysThreads;

/**
 * @author Bhavana Malli
 *
 */


	
	public class myRunnableInterface implements Runnable  {

		public void run() {
			System.out.println("it is started");
		}

		public static void main(String args[]) {
			myRunnableInterface interf = new myRunnableInterface();
			Thread thread = new Thread(interf);
			thread.start();
		}

	}


