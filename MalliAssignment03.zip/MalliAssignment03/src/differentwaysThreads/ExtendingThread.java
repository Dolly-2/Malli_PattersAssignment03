/**
 * 
 */
package differentwaysThreads;

/**
 * @author Bhavana Malli
 *
 */
public class ExtendingThread {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		class MyThread extends Thread {
		    public void run() {
		    	System.out.println("Thread extending");
		        // code to be executed in this thread
		    }
		}

		// create a thread and start it
		MyThread thread = new MyThread();
		thread.start();


	}

}
