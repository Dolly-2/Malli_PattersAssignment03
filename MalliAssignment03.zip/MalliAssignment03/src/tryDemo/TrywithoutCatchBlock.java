/**
 * 
 */
package tryDemo;

/**
 * @author Bhavana Malli
 *
 */
public class TrywithoutCatchBlock {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
	         System.out.println("This is  Try Block");
	      } finally {
	         System.out.println("Entred Finally Block");
	      }


	}

}
