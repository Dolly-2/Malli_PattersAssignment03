/**
 * 
 */
package AaarylistSync;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * @author Bhavana Malli
 *
 */
public class CollectionssycnList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 List<String> str1 = new ArrayList<String>(); 

			// Add elements in the list. 
			   str1.add("chair"); 
			   str1.add("Orange"); 
			   str1.add("car"); 
			   str1.add("bike"); 

			// Synchronizing ArrayList in Java. 
			   List<String> list = Collections.synchronizedList( str1 ); // l is non-synchronized. 

			// Here, we will use a synchronized block to avoid the non-deterministic behavior. 
			   synchronized(list) 
			   { 
			// Call iterator() method to iterate the ArrayList. 
			    Iterator<String> itr = list.iterator(); 
			    while(itr.hasNext())
			    { 
			      String str = itr.next(); 
			      System.out.println(str); 
			    } 
			  } 

	}

}
